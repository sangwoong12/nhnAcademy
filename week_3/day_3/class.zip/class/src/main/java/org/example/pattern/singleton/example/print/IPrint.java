package org.example.pattern.singleton.example.print;

import org.example.pattern.singleton.example.Account.IAccount;

public interface IPrint {
    void printAccount(IAccount account);
}
