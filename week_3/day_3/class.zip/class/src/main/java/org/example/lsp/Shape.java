package org.example.lsp;

public interface Shape {
    Number getArea();
}
