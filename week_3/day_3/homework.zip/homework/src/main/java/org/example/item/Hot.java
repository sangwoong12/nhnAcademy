package org.example.item;

/**
 * Hot 여부 확인용 인터페이스.
 */
public interface Hot {

}
