package org.example.item;

/**
 * 초코.
 */
public class Choco extends Essence implements Ice, Hot {
    public Choco() {
        this.essenceName = "Choco";
        this.drinkPrice = 2000;
    }
}
