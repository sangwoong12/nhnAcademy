package org.example.type;

/**
 * 음류 이름.
 */
public enum DrinkName {
    AMERICANO, CAFE_LATTE, CHOCE, MOCHA_CINO, PEACH_TEA
}
