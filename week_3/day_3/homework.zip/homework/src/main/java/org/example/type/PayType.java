package org.example.type;

/**
 * 결제 종류.
 */
public enum PayType {
    CASH, ONLINE, CREDIT_CARD
}
