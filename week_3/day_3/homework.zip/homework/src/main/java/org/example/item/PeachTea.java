package org.example.item;

/**
 * 복숭아 티.
 */
public class PeachTea extends Essence implements Hot {
    public PeachTea() {
        this.essenceName = "PeachTea";
        this.drinkPrice = 1600;
    }
}
