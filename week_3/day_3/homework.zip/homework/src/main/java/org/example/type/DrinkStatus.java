package org.example.type;

/**
 * 음류 상태.
 */
public enum DrinkStatus {
    HOT, ICE
}
