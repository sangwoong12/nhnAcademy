package org.example.item;

/**
 * 모카치노.
 */
public class MochaCino extends Essence implements Hot {
    public MochaCino() {
        this.essenceName = "MochaCino";
        this.drinkPrice = 3000;
    }
}
