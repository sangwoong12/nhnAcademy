package org.example.item;

/**
 * ice 여부 확인용 인테페이스.
 */
public interface Ice {

}
