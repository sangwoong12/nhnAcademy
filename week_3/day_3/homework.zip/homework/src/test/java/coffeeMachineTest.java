public class coffeeMachineTest {

    public static void main(String[] args) {
        
    }

}
