package org.example.Lab12_3.Starter;

public class Test {
    public static void main(String[] args) {
        // 
        // To-do: Write test code here
        //
    }
}
