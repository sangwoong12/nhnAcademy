create
    definer = nhn_academy_39@`%` procedure insert_dummy_posts(IN num_posts int, IN user_id varchar(20))
BEGIN
    DECLARE i INT DEFAULT 0;

    WHILE i < num_posts DO
        SET i = i + 1;
        INSERT INTO POST (TITLE, CONTENT, WRITER_USER_ID)
        VALUES
            (CONCAT('Post ', i), CONCAT('This is post number ', i), user_id);

    END WHILE;
END;

