create
    definer = nhn_academy_39@`%` procedure insert_dummy_users(IN num_users int)
BEGIN
    DECLARE i INT DEFAULT 0;

    WHILE i < num_users DO
        SET i = i + 1;
        INSERT INTO USER (ID, PASSWORD, NAME)
        VALUES
            (CONCAT('test', i), '1234', CONCAT('TEST User ', i));
    END WHILE;
END;

