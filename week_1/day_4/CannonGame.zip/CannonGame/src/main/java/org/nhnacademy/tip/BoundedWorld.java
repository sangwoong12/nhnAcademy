package org.nhnacademy.tip;

public class BoundedWorld extends MovableWorld {
    public BoundedWorld(int width, int height) {
        super(width, height);
    }

    // TODO 추가
    public void remove(Bounds bounds){
        synchronized (boundsList) {
            for (Bounds other : boundsList) {
                if (other instanceof Bounded) {
                    System.out.println("블럭 삭제");
                    ((Bounded) other).removeExcludedBounds(bounds);
                }
            }
        }
    }
    @Override
    public void add(Bounds bounds) {
        synchronized (boundsList) {
            for (Bounds other : boundsList) {
                if (other instanceof Bounded) {
                    System.out.println("볼 생성");
                    ((Bounded) other).addExcludedBounds(bounds);
                }
            }
        }

        if (bounds instanceof Bounded) {
            ((Bounded) bounds).setBounds(0, 0, getWidth(), getHeight());
            synchronized (boundsList) {
                for (Bounds other : boundsList) {
                    ((Bounded) bounds).addExcludedBounds(other);
                }
            }
        }

        super.add(bounds);
    }
}
