package com.nhnacademy.security.repository;

// marker interface
public interface RepositoryBase {
}
