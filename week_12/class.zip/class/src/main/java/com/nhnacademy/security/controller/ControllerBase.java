package com.nhnacademy.security.controller;

// marker interface
public interface ControllerBase {
}
