package com.nhnacademy.resident.repository;

public interface RepositoryBase {
}
