package com.nhnacademy.resident.domain.household_movement_address;

import com.nhnacademy.resident.entity.HouseholdMovementAddress;

public interface HouseholdMovementAddressDto {
    HouseholdMovementAddress.Pk getPk();
}
