package com.nhnacademy.resident.domain.resident;

public interface ParentDto {
    String getName();
    String getResidentRegistrationNumber();
}
