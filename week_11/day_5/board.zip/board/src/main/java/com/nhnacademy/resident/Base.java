package com.nhnacademy.resident;

public interface Base {
}
