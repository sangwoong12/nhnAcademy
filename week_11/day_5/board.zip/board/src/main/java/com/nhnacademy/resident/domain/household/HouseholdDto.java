package com.nhnacademy.resident.domain.household;

public interface HouseholdDto {
    Long getHouseholdSerialNumber();
}
