package com.nhnacademy.resident.domain.family_relationship;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class UpdateFamilyRelationDto {
    private String relationShip;
}
