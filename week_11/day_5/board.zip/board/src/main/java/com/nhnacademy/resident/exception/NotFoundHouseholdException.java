package com.nhnacademy.resident.exception;

public class NotFoundHouseholdException extends RuntimeException{
}
