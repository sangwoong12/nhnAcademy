package com.nhnacademy.resident.exception;

public class NotFoundResidentException extends RuntimeException{
}
