package com.nhnacademy.resident.domain.birth_death_report_resident;

import com.nhnacademy.resident.entity.BirthDeathReportResident;

public interface ReportResidentDto {
    BirthDeathReportResident.Pk getPk();
}
