package com.nhnacademy.resident.controller;

public interface ControllerBase {
}
