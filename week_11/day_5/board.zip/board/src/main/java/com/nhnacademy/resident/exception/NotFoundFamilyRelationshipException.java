package com.nhnacademy.resident.exception;

public class NotFoundFamilyRelationshipException extends RuntimeException {
}
