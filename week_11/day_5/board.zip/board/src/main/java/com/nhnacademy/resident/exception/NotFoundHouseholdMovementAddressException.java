package com.nhnacademy.resident.exception;

public class NotFoundHouseholdMovementAddressException extends RuntimeException{
}
