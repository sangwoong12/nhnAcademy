package com.nhnacademy.resident.exception;

public class NotFoundBirthDeathReportResidentException extends RuntimeException{
}
