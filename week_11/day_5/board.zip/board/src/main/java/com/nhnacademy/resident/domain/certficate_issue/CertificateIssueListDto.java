package com.nhnacademy.resident.domain.certficate_issue;

public interface CertificateIssueListDto {
    Long getCertificateConfirmationNumber();
    String getCertificateTypeCode();
}
