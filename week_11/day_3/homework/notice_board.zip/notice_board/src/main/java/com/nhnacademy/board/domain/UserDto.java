package com.nhnacademy.board.domain;

public interface UserDto {
    String getId();
    String getName();
}
