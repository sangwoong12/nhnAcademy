package com.nhnacademy.board.controller;

public interface ControllerBase {
}
