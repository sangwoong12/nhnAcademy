package com.nhnacademy.board.domain;

public interface UserIdOnly {
    Long getUserid();
}
