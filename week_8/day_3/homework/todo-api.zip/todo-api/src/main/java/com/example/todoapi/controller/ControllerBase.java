package com.example.todoapi.controller;

public interface ControllerBase {
}
