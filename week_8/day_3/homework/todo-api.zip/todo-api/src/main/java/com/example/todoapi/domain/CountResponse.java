package com.example.todoapi.domain;

public class CountResponse {
    int count;

    public CountResponse(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
