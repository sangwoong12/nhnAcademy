package com.example.todoapi.domain;

public class EventAddResponse {
    long id;

    public EventAddResponse(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
