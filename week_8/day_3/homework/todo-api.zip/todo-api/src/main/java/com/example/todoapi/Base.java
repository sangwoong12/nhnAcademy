package com.example.todoapi;

public interface Base {
}
