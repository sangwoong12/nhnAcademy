package com.nhnacademy.springmvcstudent;

public interface Base {
}
