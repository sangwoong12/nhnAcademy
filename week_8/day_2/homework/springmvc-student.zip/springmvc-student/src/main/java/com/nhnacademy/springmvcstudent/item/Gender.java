package com.nhnacademy.springmvcstudent.item;

public enum Gender {
    M, F, C
}