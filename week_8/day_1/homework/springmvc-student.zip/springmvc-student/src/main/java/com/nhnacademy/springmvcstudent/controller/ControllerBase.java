package com.nhnacademy.springmvcstudent.controller;

public interface ControllerBase {
}
